using System.Collections.Generic;

namespace Profiles.Core
{
    /// <summary>Synthetic, labelled examples; no user survey data.</summary>
    public static class SampleProjects
    {
        public static ProfileProject Longitudinal()
        {
            return new ProfileProject
            {
                Kind = ProfileKind.Longitudinal,
                Name = "Учебный канал — подчистка",
                Template = ProfileTemplate.Reconstruction,
                Settings = new ProfileSettings
                {
                    Title = "УЧЕБНЫЙ ПРИМЕР — РЕКОНСТРУКЦИЯ КАНАЛА",
                    HorizontalScale = 1000,
                    VerticalScale = 100,
                    Datum = 139
                },
                Longitudinal = new List<LongitudinalPoint>
                {
                    new LongitudinalPoint { Station = 0, RightBank = 143.80, LeftBank = 143.65, ExistingBottom = 141.60, Water = 142.10, ProjectBottom = 141.20, BottomWidth = 0.6, LeftSlope = 1.5, RightSlope = 1.5 },
                    new LongitudinalPoint { Station = 25, RightBank = 143.65, LeftBank = 143.50, ExistingBottom = 141.50, Water = 142.00, ProjectBottom = 141.10, BottomWidth = 0.6, LeftSlope = 1.5, RightSlope = 1.5 },
                    new LongitudinalPoint { Station = 60, RightBank = 143.55, LeftBank = 143.45, ExistingBottom = 141.40, Water = null, ProjectBottom = 140.96, BottomWidth = 0.6, LeftSlope = 1.5, RightSlope = 1.5 },
                    new LongitudinalPoint { Station = 100, RightBank = 143.35, LeftBank = 143.30, ExistingBottom = 141.20, Water = 141.80, ProjectBottom = 140.80, BottomWidth = 0.6, LeftSlope = 1.5, RightSlope = 1.5 },
                    new LongitudinalPoint { Station = 150, RightBank = 143.20, LeftBank = 143.05, ExistingBottom = 141.05, Water = 141.65, ProjectBottom = 140.60, BottomWidth = 0.8, LeftSlope = 1.5, RightSlope = 2.0 }
                }
            };
        }

        public static ProfileProject ForTemplate(ProfileTemplate template)
        {
            if (template == ProfileTemplate.NewChannel) return NewChannel();
            if (template == ProfileTemplate.Nvk) return Nvk();
            return Longitudinal();
        }

        public static ProfileProject NewChannel()
        {
            return new ProfileProject
            {
                Kind = ProfileKind.Longitudinal, Template = ProfileTemplate.NewChannel,
                Name = "Учебный новый канал",
                Settings = new ProfileSettings
                {
                    Title = "УЧЕБНЫЙ ПРИМЕР — НОВЫЙ КАНАЛ", HorizontalScale = 1000,
                    VerticalScale = 100, Datum = 139, ShowEmptyRows = true
                },
                Longitudinal = new List<LongitudinalPoint>
                {
                    new LongitudinalPoint { Station = 0, Ground = 143.8, ProjectBottom = 141.2, PeatDepth = .4, BottomWidth = .6, LeftSlope = 1.5, RightSlope = 1.5 },
                    new LongitudinalPoint { Station = 25, Ground = 143.7, BottomWidth = .6, LeftSlope = 1.5, RightSlope = 1.5 },
                    new LongitudinalPoint { Station = 60, Ground = 143.6, PeatDepth = .3, BottomWidth = .6, LeftSlope = 1.5, RightSlope = 1.5 },
                    new LongitudinalPoint { Station = 100, Ground = 143.5, ProjectBottom = 140.8, PeatDepth = .2, BottomWidth = .6, LeftSlope = 1.5, RightSlope = 1.5 }
                }
            };
        }

        public static ProfileProject Nvk()
        {
            return new ProfileProject
            {
                Kind = ProfileKind.Longitudinal, Template = ProfileTemplate.Nvk,
                Name = "Учебные сети НВК",
                Settings = new ProfileSettings
                {
                    Title = "УЧЕБНЫЙ ПРИМЕР — СЕТИ НВК", HorizontalScale = 500,
                    VerticalScale = 100, Datum = 139
                },
                Longitudinal = new List<LongitudinalPoint>
                {
                    new LongitudinalPoint { Station = 0, Ground = 143.8, ProjectGround = 144.0, PipeInvert = 141.2, PointName = "К1", PipeDescription = "ПЭ 160", Foundation = "Песок" },
                    new LongitudinalPoint { Station = 25, Ground = 143.7, PointName = "К2" },
                    new LongitudinalPoint { Station = 60, Ground = 143.6, PointName = "К3" },
                    new LongitudinalPoint { Station = 100, Ground = 143.5, ProjectGround = 143.7, PipeInvert = 140.8, PointName = "К4", PipeDescription = "ПЭ 160", Foundation = "Песок" }
                }
            };
        }

        public static ProfileProject CrossSections()
        {
            return new ProfileProject
            {
                Kind = ProfileKind.CrossSection,
                Name = "Учебные поперечники",
                Longitudinal = Longitudinal().Longitudinal,
                Settings = new ProfileSettings
                {
                    Title = "УЧЕБНЫЕ ПОПЕРЕЧНЫЕ ПРОФИЛИ КАНАЛА",
                    HorizontalScale = 100,
                    VerticalScale = 100,
                    Datum = 139
                },
                Sections = new List<CrossSection>
                {
                    new CrossSection
                    {
                        Name = "ПК 0+00.00",
                        Station = 0,
                        DesignMode = SectionDesignMode.Trapezoid,
                        CenterOffset = 0,
                        Water = 142.10,
                        ProjectBottom = 141.20,
                        BottomWidth = 0.6,
                        LeftSlope = 1.5,
                        RightSlope = 1.5,
                        SiltThickness = .2,
                        SiltLeft = -1,
                        SiltRight = 1,
                        Points = new List<SectionPoint>
                        {
                            new SectionPoint { Offset = -8, Existing = 143.70 },
                            new SectionPoint { Offset = -4, Existing = 143.65 },
                            new SectionPoint { Offset = -1, Existing = 141.80 },
                            new SectionPoint { Offset = 0, Existing = 141.60 },
                            new SectionPoint { Offset = 1, Existing = 141.85 },
                            new SectionPoint { Offset = 4, Existing = 143.80 },
                            new SectionPoint { Offset = 8, Existing = 143.85 }
                        }
                    },
                    new CrossSection
                    {
                        Name = "ПК 1+00.00",
                        Station = 100,
                        DesignMode = SectionDesignMode.Points,
                        Water = 141.80,
                        SiltThickness = .15,
                        SiltLeft = -.4,
                        SiltRight = .4,
                        Points = new List<SectionPoint>
                        {
                            new SectionPoint { Offset = -7, Existing = 143.35, Design = 143.35 },
                            new SectionPoint { Offset = -3.2, Existing = 143.25, Design = 142.70 },
                            new SectionPoint { Offset = -0.4, Existing = 141.35, Design = 140.80 },
                            new SectionPoint { Offset = 0.4, Existing = 141.30, Design = 140.80 },
                            new SectionPoint { Offset = 3.2, Existing = 143.30, Design = 143.60 },
                            new SectionPoint { Offset = 7, Existing = 143.40, Design = 143.70 }
                        }
                    }
                }
            };
        }
    }
}
